# News Application Setup

## Prerequisites
Ensure you are using **Python 3.11** or a compatible version.

## Setup Instructions

1. **Create a Virtual Environment:**
python -m venv venv
venv\Scripts\activate

2. **Install Dependencies**
pip install -r news_application/requirements.txt

3. **Run migrations**
python manage.py migrate

4. **Start the Development Server**
python manage.py runserver

## Documentation Setup

To build project documentation with Sphinx:

1. **Navigate to the 'docs/' directory**
cd docs

2. **Create a Virtual Environment for docs**
venv\Scripts\activate

3. **Install Documentation Dependencies**
pip install -r requirements.txt

4. **Build the HTML Documentation**
/make html

### Requirements for Documentation
- Sphinx: documentation generator for Python
- Alabaster: default theme for Sphinx
- Babel: used for Sphinx translations
- Docutils: parses reStructured text
- Imaagesize: determines image dimensions automatically
- Jinja2: Generates HTML output from Sphinx
- MarkupSafe: prevents injection issues in Jinja2
- Packaging: Helps with version/dependency parsing
- Snowballstemmer: Provides word stemming for Sphinx
- Roman-numerals-py: converts int to roman numerals
- Requests: used for downloading resources
- URLlib3: HTTP client used by requests
- Colorama: improves terminal output formatting for windows
- Cryptography: used for secure communcation